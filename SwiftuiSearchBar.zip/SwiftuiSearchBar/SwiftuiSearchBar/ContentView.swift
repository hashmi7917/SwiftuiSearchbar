//
//  ContentView.swift
//  SwiftuiSearchBar
//
//  Created by Imran Hashmi on 16/10/20.
//

import SwiftUI

struct ContentView: View {
    
    var columns = Array(repeating: GridItem(.flexible()), count: 2)

    @State var show = false
    @State var text = ""
    
    var body: some View {
        NavigationView {
            VStack(spacing: 5) {
                SearchBar(text: $text)
                    
                ScrollView(.vertical, showsIndicators: false) {
                    LazyVGrid(columns: columns, spacing: 0) {
                        ForEach(mData.filter({"\($0)".contains(text.lowercased()) || text.isEmpty})) { item in
                            VStack(alignment: .leading, spacing: 0) {
                                
                                Image(item.image)
                                    .resizable()
                                    .frame(width: 180, height: 250)
                                    .aspectRatio(contentMode: .fill)
                                    
                                
                                HStack {
                                    Text(item.title.uppercased())
                                        .lineLimit(1)
                                        .font(.headline)
                                        .foregroundColor(.black)
                                    
                                    Spacer()
                                    Image(systemName: show ? "heart.fill" : "heart")
                                        .foregroundColor(.red)
                                        .animation(.spring(response: 0.7, dampingFraction: 0.5, blendDuration: 0))
                                        .onTapGesture {
                                            self.show.toggle()
                                        }
                                }
                                .padding(10)
                                .background(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                                .clipped()
                                
                                    
                            }
                            .cornerRadius(10)
                            .padding()
                            .shadow(color: Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)).opacity(0.2), radius: 20, x: 0, y: 20)
                                
                            
                        }
                    }
                }
                
            }
            .navigationBarTitle("Avengers")
        }
    }
}

struct MyData: Identifiable {
    var id = UUID()
    var title: String
    var image: String
    var subtitle: String
}

var mData = [
    MyData(title: "ironman", image: "ironman", subtitle: "Avengers"),
    MyData(title: "spiderman", image: "spiderman", subtitle: "Avengers"),
    MyData(title: "captainamerica", image: "captain", subtitle: "Avengers"),
    MyData(title: "thor", image: "thor", subtitle: "Avengers"),
    MyData(title: "hulk", image: "hulk", subtitle: "Avengers"),
    MyData(title: "blackpanther", image: "panther", subtitle: "Avengers"),
    MyData(title: "scarletwitch", image: "scarlet", subtitle: "Avengers"),
    MyData(title: "antman", image: "wasp", subtitle: "Avengers"),
    MyData(title: "hawkeye", image: "hawkeye", subtitle: "Avengers"),
    MyData(title: "blackwidow", image: "widow", subtitle: "Avengers"),
    
]

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
