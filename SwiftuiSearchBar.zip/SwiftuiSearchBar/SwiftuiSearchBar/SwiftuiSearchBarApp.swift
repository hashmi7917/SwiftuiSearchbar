//
//  SwiftuiSearchBarApp.swift
//  SwiftuiSearchBar
//
//  Created by Imran Hashmi on 16/10/20.
//

import SwiftUI

@main
struct SwiftuiSearchBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
